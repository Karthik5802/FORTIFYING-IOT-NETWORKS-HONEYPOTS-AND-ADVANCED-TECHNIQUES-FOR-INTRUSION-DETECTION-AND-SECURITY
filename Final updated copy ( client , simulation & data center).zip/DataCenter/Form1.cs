﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Amazon.S3;
using Amazon.S3.Model;

namespace Org.Red.Network.PacketMonitor 
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void browse_Click(object sender, EventArgs e)
        {
            try
            {
                //openFileDialog1.ShowDialog();
                listView1.Items.Clear();
                txtBrowsFile.Text = Application.StartupPath + "\\hackerips.txt";
                FileStream fp = new FileStream(txtBrowsFile.Text, FileMode.Open);
                StreamReader reader = new StreamReader(fp);
                string record;
                while ((record = reader.ReadLine()) != null)
                {
                    string []col = record.Split(',');
                    ListViewItem L = new ListViewItem(col[0]);
                    L.SubItems.Add(col[1]);
                    listView1.Items.Add(L);
                }
 
            }
            catch (Exception ex)
            {
                MessageBox.Show("EXCEPTION:" + ex);
            }
        }
    }
}
