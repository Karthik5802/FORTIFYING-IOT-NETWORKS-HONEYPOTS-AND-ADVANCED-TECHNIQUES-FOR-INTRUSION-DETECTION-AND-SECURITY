﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
namespace Org.Red.Network.PacketMonitor
{
    public partial class ConfigureIp : Form
    {
        public ConfigureIp()
        {
            InitializeComponent();
        }

        private void ConfigureIp_Load(object sender, EventArgs e)
        {
            if (File.Exists("ips.txt"))
            {
                string [ ] ips = File.ReadAllLines("ips.txt");
                for (int i = 0; i < ips.Length; i++)
                {
                    lstIps.Items.Add(ips[i]);
                }
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (TxtIp.Text.Length == 0)
                MessageBox.Show("Empty ip address not allowed", "Ip Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                IPAddress ip;
                bool ValidateIP = IPAddress.TryParse(TxtIp.Text, out ip);  
                if (lstIps.Items.Contains(TxtIp.Text) == false && ValidateIP)
                {
                    lstIps.Items.Add(TxtIp.Text);
                    TxtIp.Clear();
                    TxtIp.Focus();
                }
                else
                    MessageBox.Show("Ip format invalid or Ip already exists", "Ip Validation", MessageBoxButtons.OK, MessageBoxIcon.Information);
    
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (File.Exists("ips.txt"))
                File.Delete("ips.txt");

            string contents = "";
            for (int i = 0; i < lstIps.Items.Count; i++)
            {
                contents += lstIps.Items[i].ToString() + "\n";
            }
            File.WriteAllText("ips.txt", contents);
            MessageBox.Show("Ip configuration saved successfully", "Ip configurator", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BntClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstIps.SelectedIndices.Count > 0)
            {
                DialogResult res = MessageBox.Show("Are you sure ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if( res == System.Windows.Forms.DialogResult.Yes )
                lstIps.Items.RemoveAt(lstIps.SelectedIndex);
            }
        }
    }
}
