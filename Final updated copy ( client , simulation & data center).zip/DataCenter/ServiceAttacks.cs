﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PacketMonitor
{
    public class ServiceAttacks
    {
        public string servicename { set; get; }
        public string port { set; get; }
    }
}
