using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Threading;
using System.Media;
using System.IO;
using System.Collections.Generic;
using PacketMonitor;
using System.Diagnostics;
using System.Net.Sockets;
using RequestPackets;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using System.Text;
namespace Org.Red.Network.PacketMonitor {
    public class PacketMonitormForm : System.Windows.Forms.Form
    {
        private delegate void UpdatePacketList(Packet p);


        Dictionary<string, PacketDuration> IPDict;
        private Button btnAdd;
        Thread requestHandler;
        private Button frmSecureLog;
         ArrayList ips;

         MqttClient client = null;
         string clientId;
         string mqttserverip = "broker.hivemq.com";
         string ReceivedMessage = null;

        public PacketMonitormForm()
        {
            // Required for Windows Form Designer support
            InitializeComponent();
            // initialize packet monitor
            IPDict = new Dictionary<string, PacketDuration>();
            Initialize();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PacketMonitormForm));
            this.ToolBar = new System.Windows.Forms.ToolBar();
            this.StartButton = new System.Windows.Forms.ToolBarButton();
            this.HostsMenu = new System.Windows.Forms.ContextMenu();
            this.StopButton = new System.Windows.Forms.ToolBarButton();
            this.ClearButton = new System.Windows.Forms.ToolBarButton();
            this.ThresholdBtn = new System.Windows.Forms.ToolBarButton();
            this.AboutButton = new System.Windows.Forms.ToolBarButton();
            this.ToobarImages = new System.Windows.Forms.ImageList(this.components);
            this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
            this.StatusBar = new System.Windows.Forms.StatusBar();
            this.PacketList = new System.Windows.Forms.ListView();
            this.TimeHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ProtocolHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SourceHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DestinationHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LengthHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ConnectionMonitoringList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.traceRouteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label4 = new System.Windows.Forms.Label();
            this.IOTRequestViewer = new System.Windows.Forms.ListView();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnAdd = new System.Windows.Forms.Button();
            this.BtnStopService = new System.Windows.Forms.Button();
            this.BtnStartService = new System.Windows.Forms.Button();
            this.frmSecureLog = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolBar
            // 
            this.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.ToolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.StartButton,
            this.StopButton,
            this.ClearButton,
            this.ThresholdBtn,
            this.AboutButton});
            this.ToolBar.Cursor = System.Windows.Forms.Cursors.Default;
            this.ToolBar.DropDownArrows = true;
            this.ToolBar.ImageList = this.ToobarImages;
            this.ToolBar.Location = new System.Drawing.Point(0, 24);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.ShowToolTips = true;
            this.ToolBar.Size = new System.Drawing.Size(889, 28);
            this.ToolBar.TabIndex = 1;
            this.ToolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.OnToolBarClick);
            // 
            // StartButton
            // 
            this.StartButton.DropDownMenu = this.HostsMenu;
            this.StartButton.ImageIndex = 0;
            this.StartButton.Name = "StartButton";
            this.StartButton.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
            this.StartButton.ToolTipText = "Start monitoring";
            // 
            // StopButton
            // 
            this.StopButton.ImageIndex = 1;
            this.StopButton.Name = "StopButton";
            this.StopButton.ToolTipText = "Stop monitoring";
            // 
            // ClearButton
            // 
            this.ClearButton.ImageIndex = 3;
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.ToolTipText = "Clear packet list";
            // 
            // ThresholdBtn
            // 
            this.ThresholdBtn.ImageIndex = 4;
            this.ThresholdBtn.Name = "ThresholdBtn";
            this.ThresholdBtn.ToolTipText = "Click to set threshold";
            // 
            // AboutButton
            // 
            this.AboutButton.ImageIndex = 2;
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.ToolTipText = "About...";
            // 
            // ToobarImages
            // 
            this.ToobarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ToobarImages.ImageStream")));
            this.ToobarImages.TransparentColor = System.Drawing.Color.Magenta;
            this.ToobarImages.Images.SetKeyName(0, "");
            this.ToobarImages.Images.SetKeyName(1, "");
            this.ToobarImages.Images.SetKeyName(2, "");
            this.ToobarImages.Images.SetKeyName(3, "");
            this.ToobarImages.Images.SetKeyName(4, "1486650884_Vector-icons_89.png");
            // 
            // StatusBar
            // 
            this.StatusBar.Location = new System.Drawing.Point(0, 486);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(889, 16);
            this.StatusBar.TabIndex = 3;
            // 
            // PacketList
            // 
            this.PacketList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TimeHeader,
            this.ProtocolHeader,
            this.SourceHeader,
            this.DestinationHeader,
            this.LengthHeader});
            this.PacketList.FullRowSelect = true;
            this.PacketList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.PacketList.Location = new System.Drawing.Point(15, 87);
            this.PacketList.MultiSelect = false;
            this.PacketList.Name = "PacketList";
            this.PacketList.Size = new System.Drawing.Size(316, 176);
            this.PacketList.TabIndex = 4;
            this.PacketList.UseCompatibleStateImageBehavior = false;
            this.PacketList.View = System.Windows.Forms.View.Details;
            this.PacketList.DoubleClick += new System.EventHandler(this.OnPacketDoubleClick);
            // 
            // TimeHeader
            // 
            this.TimeHeader.Text = "Time";
            this.TimeHeader.Width = 62;
            // 
            // ProtocolHeader
            // 
            this.ProtocolHeader.Text = "Protocol";
            // 
            // SourceHeader
            // 
            this.SourceHeader.Text = "Source";
            this.SourceHeader.Width = 83;
            // 
            // DestinationHeader
            // 
            this.DestinationHeader.Text = "Destination";
            this.DestinationHeader.Width = 130;
            // 
            // LengthHeader
            // 
            this.LengthHeader.Text = "Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Complete packet capturing";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(282, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Connection monitoring for Ledger request";
            // 
            // ConnectionMonitoringList
            // 
            this.ConnectionMonitoringList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.ConnectionMonitoringList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.ConnectionMonitoringList.Location = new System.Drawing.Point(15, 304);
            this.ConnectionMonitoringList.Name = "ConnectionMonitoringList";
            this.ConnectionMonitoringList.Size = new System.Drawing.Size(851, 176);
            this.ConnectionMonitoringList.TabIndex = 7;
            this.ConnectionMonitoringList.UseCompatibleStateImageBehavior = false;
            this.ConnectionMonitoringList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Source";
            this.columnHeader1.Width = 140;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Port";
            this.columnHeader2.Width = 168;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Connection Duration";
            this.columnHeader3.Width = 238;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Connected start time";
            this.columnHeader4.Width = 157;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Time elapsed";
            this.columnHeader5.Width = 138;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.traceRouteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(133, 26);
            // 
            // traceRouteToolStripMenuItem
            // 
            this.traceRouteToolStripMenuItem.Name = "traceRouteToolStripMenuItem";
            this.traceRouteToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.traceRouteToolStripMenuItem.Text = "Trace route";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(889, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(336, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 18);
            this.label4.TabIndex = 11;
            this.label4.Text = "Ledger Request viewer";
            // 
            // IOTRequestViewer
            // 
            this.IOTRequestViewer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13});
            this.IOTRequestViewer.Location = new System.Drawing.Point(339, 87);
            this.IOTRequestViewer.Name = "IOTRequestViewer";
            this.IOTRequestViewer.Size = new System.Drawing.Size(527, 176);
            this.IOTRequestViewer.TabIndex = 12;
            this.IOTRequestViewer.UseCompatibleStateImageBehavior = false;
            this.IOTRequestViewer.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "IP";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "M/c";
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "User";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Request";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(248, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(119, 23);
            this.btnAdd.TabIndex = 21;
            this.btnAdd.Text = "Add machines";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // BtnStopService
            // 
            this.BtnStopService.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnStopService.BackgroundImage")));
            this.BtnStopService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnStopService.Location = new System.Drawing.Point(124, 0);
            this.BtnStopService.Name = "BtnStopService";
            this.BtnStopService.Size = new System.Drawing.Size(118, 24);
            this.BtnStopService.TabIndex = 14;
            this.BtnStopService.Text = "Stop Service";
            this.BtnStopService.UseVisualStyleBackColor = true;
            this.BtnStopService.Click += new System.EventHandler(this.BtnStopService_Click);
            // 
            // BtnStartService
            // 
            this.BtnStartService.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnStartService.BackgroundImage")));
            this.BtnStartService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnStartService.Location = new System.Drawing.Point(0, 0);
            this.BtnStartService.Name = "BtnStartService";
            this.BtnStartService.Size = new System.Drawing.Size(118, 24);
            this.BtnStartService.TabIndex = 13;
            this.BtnStartService.Text = "Start Service";
            this.BtnStartService.UseVisualStyleBackColor = true;
            this.BtnStartService.Click += new System.EventHandler(this.BtnStartService_Click);
            // 
            // frmSecureLog
            // 
            this.frmSecureLog.Location = new System.Drawing.Point(373, 0);
            this.frmSecureLog.Name = "frmSecureLog";
            this.frmSecureLog.Size = new System.Drawing.Size(121, 24);
            this.frmSecureLog.TabIndex = 22;
            this.frmSecureLog.Text = "Secure log";
            this.frmSecureLog.UseVisualStyleBackColor = true;
            this.frmSecureLog.Click += new System.EventHandler(this.frmSecureLog_Click);
            // 
            // PacketMonitormForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(889, 502);
            this.Controls.Add(this.frmSecureLog);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.BtnStopService);
            this.Controls.Add(this.BtnStartService);
            this.Controls.Add(this.IOTRequestViewer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ConnectionMonitoringList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PacketList);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.ToolBar);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Menu = this.MainMenu;
            this.Name = "PacketMonitormForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Network analysis";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.PacketMonitormForm_Closing);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PacketMonitormForm_FormClosing);
            this.Load += new System.EventHandler(this.PacketMonitormForm_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        static void Main()
        {
            try
            {
                //Application.Run(new LoginScreen());
                //Application.Run(new MainScreen());
                Application.Run(new PacketMonitormForm());
                //Application.Run(new ViewTraceLog());
                //Application.Run(new AboutForm());
                //Application.Run(new AttackReport());

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Red.org Packet Monitor", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Initialize()
        {
            ips = new ArrayList();
            if (File.Exists("ips.txt"))
            {
                string[] ipliststr = File.ReadAllLines("ips.txt");
                for (int i = 0; i < ipliststr.Length; i++)
                {
                    ips.Add(ipliststr[i]);
                }
            }
            // get all interfaces on this computer and list them
            IPAddress[] hosts = Dns.Resolve(Dns.GetHostName()).AddressList;
            if (hosts.Length == 0)
                throw new NotSupportedException("This computer does not have non-loopback interfaces installed!");
            for (int i = 0; i < hosts.Length; i++)
            {
                //MonitorMenuItem.MenuItems.Add(hosts[i].ToString(), new EventHandler(this.OnHostsClick));
                HostsMenu.MenuItems.Add(hosts[i].ToString(), new EventHandler(this.OnHostsClick));
            }
            m_PacketMonitors = new PacketMonitor[HostsMenu.MenuItems.Count];
            for (int i = 0; i < m_PacketMonitors.Length; i++)
            {
                m_PacketMonitors[i] = new PacketMonitor(hosts[i]);
                m_PacketMonitors[i].NewPacket += new NewPacketEventHandler(this.OnNewPacket);
            }
            m_Packets = new ArrayList();

            client = new MqttClient(mqttserverip);
            client.Subscribe(new string[] { "cybersecurepot/gps" }, new byte[] { 2 });

            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);

        }

        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            // lat , lon
            ReceivedMessage = Encoding.UTF8.GetString(e.Message);
        }

        private void PacketMonitormForm_Closing(object sender, CancelEventArgs e)
        {
            OnToolBarClick(this, new ToolBarButtonClickEventArgs(StopButton));
        }

        public void OnToolBarClick(object sender, ToolBarButtonClickEventArgs e)
        {
 

            if (e.Button == StopButton)
            {  
                for (int i = 0; i < m_PacketMonitors.Length; i++)
                {
                    m_PacketMonitors[i].Stop();
                    HostsMenu.MenuItems[i].Checked = false;
                    //MonitorMenuItem.MenuItems[i].Checked = false;
                }
                StatusBar.Text = "Stopped monitoring";
            }
            else if (e.Button == StartButton)
            { // start listening on all interfaces
                for (int i = 0; i < m_PacketMonitors.Length; i++)
                {
                    try
                    {
                        m_PacketMonitors[i].Start();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "There was a problem starting the packet monitor for interface " + m_PacketMonitors[i].IP.ToString() + "\r\n\r\n[" + ex.Message + "]", "Red.org Packet Monitor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    HostsMenu.MenuItems[i].Checked = true;
                    //MonitorMenuItem.MenuItems[i].Checked = true;
                }
                StatusBar.Text = "Monitoring all interfaces";
            }
            else if (e.Button == ClearButton)
            { // clear the packet list
                PacketList.Items.Clear();
                m_Packets.Clear();
                StatusBar.Text = "Cleared packet list";
            }
        }
        public void OnHostsClick(object sender, EventArgs e)
        {
            // start or stop listening on the specified interface
            int index = ((MenuItem)sender).Index;
            HostsMenu.MenuItems[index].Checked = !HostsMenu.MenuItems[index].Checked;
            //MonitorMenuItem.MenuItems[index].Checked = HostsMenu.MenuItems[index].Checked;
            if (HostsMenu.MenuItems[index].Checked)
            {
                m_PacketMonitors[index].Start();
                StatusBar.Text = "Monitoring " + m_PacketMonitors[index].IP.ToString();
            }
            else
            {
                m_PacketMonitors[index].Stop();
                StatusBar.Text = "Stopped monitoring " + m_PacketMonitors[index].IP.ToString();
            }
        }
        public void OnPacketDoubleClick(object sender, EventArgs e)
        {
            ListView l = (ListView)sender;
            if (l.SelectedItems.Count > 0)
            {
                PacketForm pf = new PacketForm((Packet)m_Packets[l.SelectedItems[0].Index]);
                pf.Show();
            }
        }
        private void OnNewPacket(PacketMonitor pm, Packet p)
        {
           GlobalPacket = p;
            Global.PacketForGraph = p;
            m_Packets.Add(p);
            m_PacketsSize += p.TotalLength;

            string[] IpPortSrc = p.Source.Split(':');
            string[] IpPortDst = p.Destination.Split(':');
            ListViewItem L = new ListViewItem(p.Time.ToString());
            L.SubItems.Add(p.Protocol.ToString());
            L.SubItems.Add(p.Source);
            L.SubItems.Add(p.Destination);
            //L.SubItems.Add(p.TotalLength.ToString());
            L.SubItems.Add(p.SourcePort + ":" + p.DestinationPort);
            PacketList.Items.Add(L);

            string sourceip = IpPortSrc[0];
            PacketDuration pd = null;
            if (IPDict.ContainsKey(sourceip) == false)
            {
                pd = new PacketDuration();
                pd.TcpIpPacket = p;
                pd.Start = DateTime.Now;
                pd.End = DateTime.Now;
                IPDict.Add(sourceip, pd);
            }
            else
            {
                pd = (PacketDuration)IPDict[sourceip];
                pd.End = DateTime.Now;
                IPDict.Remove(sourceip);
                IPDict.Add(sourceip, pd);
            }

            ListViewItem CML = new ListViewItem(sourceip);
            CML.Name = sourceip;
            CML.SubItems.Add(IpPortSrc[1]);
            CML.SubItems.Add(pd.Start.ToString());
            CML.SubItems.Add(pd.End.ToString());
            CML.SubItems.Add(pd.AttackDuration.ToString());

            int pos = ConnectionMonitoringList.Items.IndexOfKey(sourceip);
            //if (pos != -1)  // found
              //  ConnectionMonitoringList.Items.RemoveAt(pos);

            if(  p.SourcePort  == 5000)
                ConnectionMonitoringList.Items.Add(CML);
          

            ListViewItem intruderItem = new ListViewItem(sourceip);
            intruderItem.SubItems.Add(pd.AttackDuration.ToString());
            intruderItem.SubItems.Add(pd.TcpIpPacket.DestinationPort.ToString());
            intruderItem.SubItems.Add(pd.TcpIpPacket.Protocol.ToString());
            intruderItem.Name = sourceip;
            
        }

        private void OnUpdatePacketList(Packet p)
        {
            string[] IpPortSrc = p.Source.Split(':');
            string[] IpPortDst = p.Destination.Split(':');
            ListViewItem L = new ListViewItem(p.Time.ToString());
            L.SubItems.Add(p.Protocol.ToString());
            L.SubItems.Add(p.Source);
            L.SubItems.Add(p.Destination);
            L.SubItems.Add(p.TotalLength.ToString());
            #region Alert indication
            //if (Global.IpList.Contains(IpPortSrc[0]) == false )
            //{
            //    SoundPlayer spWave;
            //    spWave = new SoundPlayer(System.IO.Directory.GetCurrentDirectory() + "/alarm.wav");
            //    L.BackColor = System.Drawing.Color.Red;
            //    spWave.Play();
            //    if (Global.IntruderList.Contains(IpPortSrc[0]))
            //        Global.IntruderList.Add(IpPortSrc[0]);
            //}
            //else if (Global.IntruderList.Contains(IpPortDst[0]) == true)
            //{
            //    SoundPlayer spWave;
            //    spWave = new SoundPlayer(System.IO.Directory.GetCurrentDirectory() + "/alarm.wav");
            //    L.BackColor = System.Drawing.Color.Red;
            //    spWave.Play();
            //}
            #endregion
            PacketList.Items.Add(L);

            string sourceip = IpPortSrc[0];
            PacketDuration pd = (PacketDuration)IPDict[sourceip];
            if (pd == null)
            {
                pd = new PacketDuration();
                pd.TcpIpPacket = p;
                pd.Start = DateTime.Now;
                pd.End = DateTime.Now;
                IPDict.Add(IpPortSrc[0], pd);
            }
            else
            {
                pd.End = DateTime.Now;
                IPDict.Remove(sourceip);
                IPDict.Add(sourceip, pd);
            }

            ListViewItem CML = new ListViewItem(sourceip);
            CML.SubItems.Add(IpPortSrc[1]);
            CML.SubItems.Add(pd.Start.ToString());
            CML.SubItems.Add(pd.End.ToString());
            CML.SubItems.Add(pd.AttackDuration.ToString());
            ConnectionMonitoringList.Items.Add(CML);

            //PacketList.Items.Add(new ListViewItem(new string[] { p.Time.ToString(), p.Protocol.ToString(), p.Source, p.Destination, p.TotalLength.ToString() }));
            StatusBar.Text = string.Format("Intercepted {0} packet(s) [{1} bytes]", m_Packets.Count, m_PacketsSize);
        }

        private void StopMenuItem_Click(object sender, System.EventArgs e)
        {
            OnToolBarClick(this, new ToolBarButtonClickEventArgs(StopButton));
        }
        private void ClearMenuItem_Click(object sender, System.EventArgs e)
        {
            OnToolBarClick(this, new ToolBarButtonClickEventArgs(ClearButton));
        }
        private void AboutMenuItem_Click(object sender, System.EventArgs e)
        {
            OnToolBarClick(this, new ToolBarButtonClickEventArgs(AboutButton));
        }
        private void ExitMenuItem_Click(object sender, System.EventArgs e)
        {
            GetIpThreads.Abort();
            SaveIntruderList();
            for (int i = 0; i < Application.OpenForms.Count; i++)
                Application.OpenForms[i].Close();

            Application.Exit();
        }

        #region Designer 
        private System.Windows.Forms.ListView PacketList;
        private System.Windows.Forms.MainMenu MainMenu;
        private System.Windows.Forms.ImageList ToobarImages;
        private System.Windows.Forms.ToolBar ToolBar;
        private System.Windows.Forms.StatusBar StatusBar;
        private System.Windows.Forms.ToolBarButton StartButton;
        private System.Windows.Forms.ToolBarButton StopButton;
        private System.Windows.Forms.ToolBarButton AboutButton;
        private System.Windows.Forms.ToolBarButton ClearButton;
        private System.Windows.Forms.ColumnHeader TimeHeader;
        private System.Windows.Forms.ColumnHeader ProtocolHeader;
        private System.Windows.Forms.ColumnHeader SourceHeader;
        private System.Windows.Forms.ColumnHeader DestinationHeader;
        private System.Windows.Forms.ColumnHeader LengthHeader;
        private System.Windows.Forms.ContextMenu HostsMenu;
        private System.ComponentModel.IContainer components;
        private PacketMonitor[] m_PacketMonitors;
        private Packet GlobalPacket;
        private ArrayList m_Packets;
        private int m_PacketsSize = 0;
        private Thread delay = null;
        private Label label1;
        private Label label2;
        private ListView ConnectionMonitoringList;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ToolBarButton ThresholdBtn;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem traceRouteToolStripMenuItem;
        private MenuStrip menuStrip1;
        private Thread redThread = null;
        private Label label4;
        private ListView IOTRequestViewer;
        private ColumnHeader columnHeader10;
        private ColumnHeader columnHeader11;
        private ColumnHeader columnHeader12;
        private ColumnHeader columnHeader13;
        private Button BtnStartService;
        private Button BtnStopService;
        public Process Compiler = new Process();

        #endregion

      
        private void menuItem5_Click(object sender, EventArgs e)
        {
            redThread = new Thread(new ThreadStart(redAlgorithm));
            redThread.Start();
            delay = new Thread(new ThreadStart(delayFunc));
            delay.Start();
        }
        private void delayFunc()
        {
            Thread.Sleep(Global.QSecs * 1000);
            redThread.Abort();
            delay.Abort();
        }
        public void redAlgorithm()
        {
            while (true)
            {
                try
                {
                    if (GlobalPacket.Source == null) continue;
                    if (Global.hashtable.ContainsKey(GlobalPacket.Source))
                    {
                        string val = Convert.ToString(int.Parse(Global.hashtable[GlobalPacket.Source].ToString()) + 1);
                        //MessageBox.Show(val);
                        Global.hashtable.Remove(GlobalPacket.Source);
                        Global.hashtable.Add(GlobalPacket.Source, val);
                    }
                    else
                        Global.hashtable.Add(GlobalPacket.Source, "1");
                }
                catch (Exception e) { }
            }
        }
       
       
        private void menuItem6_Click(object sender, EventArgs e)
        {
            if (redThread.IsAlive && delay.IsAlive)
            {
                MessageBox.Show("Stop Red algorithm calibration thread , Before goto red alert list", "Red algorithm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            redThread.Abort();
            delay.Abort();
        }

       
        Thread GetIpThreads;
        int[] UTI;
        Db obj = null;
        private void PacketMonitormForm_Load(object sender, EventArgs e)
        {
            UTI = new int[3];
            obj = new Db();
            
            IPAddress[] hosts = Dns.Resolve(Dns.GetHostName()).AddressList;
            Global.IpList.Add(hosts[0].ToString());
            
          
            ListView.CheckForIllegalCrossThreadCalls = false;
        }
        private void PacketMonitormForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveIntruderList();
        }
        private void SaveIntruderList()
        {
            System.IO.FileStream fp = new System.IO.FileStream("c:/intruder.txt", System.IO.FileMode.Create);
            System.IO.StreamWriter writer = new System.IO.StreamWriter(fp);
            for (int i = 0; i < Global.IntruderList.Count; i++)
            {
                string ip = Global.IntruderList[i].ToString().TrimStart().TrimEnd();
                if (i < Global.IntruderList.Count - 1)
                    writer.WriteLine(ip + ",");
                else
                    writer.WriteLine(ip);
            }
            writer.Close();
            fp.Close();
        }
       
      
        public bool Compile(string arguments)
        {
            Compiler.StartInfo.FileName = "tracert";
            Compiler.StartInfo.Arguments = arguments;
            Compiler.StartInfo.WorkingDirectory = Application.StartupPath;
            Compiler.StartInfo.CreateNoWindow = true;
            Compiler.StartInfo.ErrorDialog = false;
            Compiler.StartInfo.UseShellExecute = false;
            Compiler.StartInfo.RedirectStandardOutput = true;
            Compiler.StartInfo.RedirectStandardError = true;
            bool processStarted = Compiler.Start();
            return processStarted;
        }
        
        private void BtnStartService_Click(object sender, EventArgs e)
        {
            if (requestHandler == null)
            {
                requestHandler = new Thread(new ThreadStart(Service));
                requestHandler.Start();
            }
            else
                MessageBox.Show("Service already started", "Service handler", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        TcpListener listener = null;
        public void Service()
        {
            listener = new TcpListener(5000);
            listener.Start();
            while (requestHandler.IsAlive)
            {
                Socket client = listener.AcceptSocket();
                //int sz = client.Available;
                byte[] _rawtmp = new byte[500];
                int sz = client.Receive(_rawtmp);
                byte[] rawdata = new byte[sz];
                Array.Copy(_rawtmp, rawdata, sz);
                RequestPacket packet = DataHandler.Deserialize<RequestPacket>(rawdata);
                 
                ListViewItem item = new ListViewItem(packet.Ip);
                item.SubItems.Add(packet.MachineName);
                item.SubItems.Add(packet.Username);
                item.SubItems.Add(packet.Reqtype);
                IOTRequestViewer.Items.Add(item);

                client.Close();
                try
                {
                    if (ips.Contains(packet.Ip) == true)
                    {
                        //string ledgerlocation = getLeaderData("LedgerData.txt", packet.Reqtype);
                        if (ReceivedMessage != null)
                        {
                            string gpsLocation = ReceivedMessage;
                            bool r = obj.Add(packet.Ip, packet.MachineName, packet.Username, packet.Reqtype, gpsLocation);
                        }
                    }
                    else
                    {
                        //string ledgerlocation = getLeaderData("FakeData.txt", packet.Reqtype);
                        Random rnd = new Random();
                        string gpsLocation = 12 + "." + rnd.NextDouble() + "," + 73 + "." + rnd.NextDouble();
                        bool r = obj.Add(packet.Ip, packet.MachineName, packet.Username, packet.Reqtype, gpsLocation);

                        FileStream fp = new FileStream("hackerips.txt", FileMode.Append);
                        StreamWriter writer = new StreamWriter(fp);
                        writer.WriteLine(DateTime.Now.ToString() + "," + packet.Ip + "," + packet.Reqtype.Trim());
                        writer.Close();
                        fp.Close();
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
            }
        }

        private string getLeaderData(string filename , string patid)
        {
            FileStream fp = new FileStream(filename, FileMode.Open);
            StreamReader reader = new StreamReader(fp);
            string record="Not found";
            string ledgerlocation="Not found";
            while ((record = reader.ReadLine()) != null)
            {
                string[] cols = record.Split('@');
                if (cols[0] == patid)
                {
                    ledgerlocation = cols[1];
                    break;
                }
            }
            reader.Close();
            fp.Close();
            return ledgerlocation;
        }


        private void BtnStopService_Click(object sender, EventArgs e)
        {
            if (listener != null)
                listener.Stop();

            if (requestHandler != null)
                requestHandler.Abort();
        }

        private void CustomizationPicBtn_Click(object sender, EventArgs e)
        {
             
        }

      

        private void ResetLoadPicBtn_Click(object sender, EventArgs e)
        {
            ConnectionMonitoringList.Items.Clear();
            IOTRequestViewer.Items.Clear();
            IPDict.Clear();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ConfigureIp frm = new ConfigureIp();
            frm.ShowDialog();
        }

        private void frmSecureLog_Click(object sender, EventArgs e)
        {
            Form1 securelog = new Form1();
            securelog.Show();
        }
    }
}
 