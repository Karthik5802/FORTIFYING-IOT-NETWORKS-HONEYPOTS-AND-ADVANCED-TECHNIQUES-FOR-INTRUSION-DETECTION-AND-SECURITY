﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
namespace Org.Red.Network.PacketMonitor
{
    class Db
    {
        MySqlConnection con = null;
        MySqlCommand cmd = null;
        public Db()
        {
            con = new MySqlConnection("server=148.72.232.170;database=dbmetric;user id=usrdbmetric;pwd=Yy2iy18^;port=3306");
     
             con.Open();
            cmd = new MySqlCommand();
            cmd.Connection = con;
        }

        public bool Add( string ipaddress , string mac , string user , string reqtype , string ledgerlocation)
        {
            bool flag = false;
            try
            {
                string sql = string.Format("insert into RequestHandler( ipaddress , machinename, username , requesttype , data , status) values('{0}' , '{1}' , '{2}' , '{3}' , '{4}' , 'Y')", ipaddress, mac, user, reqtype ,ledgerlocation );
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                flag = cmd.ExecuteNonQuery() != 0 ? true : false;
            }
            catch (Exception e)
            {

            }
            return flag;
        }

    }
}
