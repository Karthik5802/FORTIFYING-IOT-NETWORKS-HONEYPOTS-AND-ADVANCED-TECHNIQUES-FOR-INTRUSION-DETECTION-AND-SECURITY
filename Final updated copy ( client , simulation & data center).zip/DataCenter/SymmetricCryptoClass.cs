﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Org.Red.Network.PacketMonitor 
{
    public class SymmetricCryptoClass
    {
       
        public static bool EncryptFile(string _filePath, string key)
        {
            
            byte[] _plainByte = File.ReadAllBytes(_filePath);

            // Encrypted string to return
            byte[] _cipherByte = null;

            byte[] initializationVector = Encoding.ASCII.GetBytes("abcede0123456789");

            using (Aes aes = Aes.Create())
            {
                //aes.Key = Encoding.UTF8.GetBytes(key);
                //aes.IV = initializationVector;

                byte[] passBytes = Encoding.UTF8.GetBytes(key);
                byte[] EncryptionkeyBytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

                int len = passBytes.Length;
                if (len > EncryptionkeyBytes.Length)
                {
                    len = EncryptionkeyBytes.Length;
                }
                Array.Copy(passBytes, EncryptionkeyBytes, len);

                aes.Key = EncryptionkeyBytes;
                aes.IV = EncryptionkeyBytes;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                 using (MemoryStream _msEncrypt = new MemoryStream())
                {
                    using (CryptoStream _csEncrypt = new CryptoStream(_msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (BinaryWriter _bwEncrypt = new BinaryWriter(_csEncrypt))
                        {
                            //Write all data to the stream
                            _bwEncrypt.Write(_plainByte);
                        }
                    }
                    _cipherByte = _msEncrypt.ToArray();
                }
            }

            File.WriteAllBytes(_filePath, _cipherByte);
            return true;
        }

        public static bool DecryptFile(string _filePath, string key)
        {
            byte[] _cipherByte = File.ReadAllBytes(_filePath);
            // Decrypted string to return
            byte[] _plainByte = null;

            using (Aes aes = Aes.Create())
            {


                //Get RijndaelManaged Keys (MainKey & IV)
                byte[] pwdBytes = Encoding.UTF8.GetBytes(key);
                byte[] keyBytes = new byte[0x10];
                int len = pwdBytes.Length;
                if (len > keyBytes.Length)
                {
                    len = keyBytes.Length;
                }
                Array.Copy(pwdBytes, keyBytes, len);
                aes.Key = keyBytes;
                aes.IV = keyBytes;

                // Create a transformer object to perform the stream transform
                ICryptoTransform _decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                // Create the streams used for decryption               
                using (MemoryStream _msDecrypt = new MemoryStream(_cipherByte))
                {
                    using (CryptoStream _csDecrypt = new CryptoStream(_msDecrypt, _decryptor, CryptoStreamMode.Read))
                    {
                        using (BinaryReader _brDecrypt = new BinaryReader(_csDecrypt))
                        {
                            // Read the decrypted bytes from the decrypting stream and place them in a string
                            _plainByte = _brDecrypt.ReadBytes(_cipherByte.Length);
                        }
                    }
                }
            }
            

            File.WriteAllBytes(_filePath, _plainByte);
            return true;
        }
        
    }
}
