﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Org.Red.Network.PacketMonitor
{
    class PacketDuration
    {
        Packet p = null;
        DateTime STime, ETime;

        public Packet TcpIpPacket
        {
            set { p = value; }
            get { return p; }
        }
        public DateTime Start
        {
            set { STime = value; }
            get { return STime; }
        }
        public DateTime End
        {
            set { ETime = value; }
            get { return ETime; }
        }
        public int AttackDuration
        {
            get
            {
                TimeSpan span = ETime.Subtract(STime);
                return span.Seconds;
            }
        }
    }
}
