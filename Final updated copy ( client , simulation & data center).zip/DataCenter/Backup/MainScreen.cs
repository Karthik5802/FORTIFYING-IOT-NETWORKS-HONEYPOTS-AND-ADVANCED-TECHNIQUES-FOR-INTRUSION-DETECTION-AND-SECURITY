﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Org.Red.Network.PacketMonitor
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        PacketMonitormForm pktFrm;
        FloodGraph grFrm;
        Mobile mobileFrm;
        IntruderList intruderFrm;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pktFrm = new PacketMonitormForm();
            pktFrm.MdiParent = this;
            pktFrm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            grFrm = new FloodGraph();
            grFrm.MdiParent = this;
            grFrm.Show();
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            
          
            
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Application.OpenForms.Count; i++)
                Application.OpenForms[i].Close();

            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            mobileFrm = new Mobile();
            mobileFrm.MdiParent = this;
            mobileFrm.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            intruderFrm = new IntruderList();
            intruderFrm.MdiParent = this;
            intruderFrm.Show();
        }
    }
}