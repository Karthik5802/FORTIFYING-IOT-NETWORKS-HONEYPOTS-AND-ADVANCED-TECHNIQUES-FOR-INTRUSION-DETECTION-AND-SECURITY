﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
namespace Org.Red.Network.PacketMonitor
{
    class UdpReceiver
    {
         int groupPort;
        Socket listener = null;
        EndPoint ep = null;
        public UdpReceiver(int port)
        {
            groupPort = port;
            listener = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPEndPoint iep = new IPEndPoint(IPAddress.Any, port );
            listener.Bind(iep);
           ep = (EndPoint)iep;
        }

        public string Receive()
        {
            byte[] data = new byte[1024];
            int recv = listener.ReceiveFrom(data, ref ep);
            string stringData = Encoding.ASCII.GetString(data, 0, recv);
            return stringData+":" + ep.ToString();
        }
    }
}
