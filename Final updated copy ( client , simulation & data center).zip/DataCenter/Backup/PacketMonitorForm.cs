using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Threading;
using System.Media;
using System.IO;
namespace Org.Red.Network.PacketMonitor {
	public class PacketMonitormForm : System.Windows.Forms.Form {
        private delegate void UpdatePacketList(Packet p);
        
        public PacketMonitormForm() {
			// Required for Windows Form Designer support
			InitializeComponent();
			// initialize packet monitor
			Initialize();
		}
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PacketMonitormForm));
            this.ToolBar = new System.Windows.Forms.ToolBar();
            this.StartButton = new System.Windows.Forms.ToolBarButton();
            this.HostsMenu = new System.Windows.Forms.ContextMenu();
            this.StopButton = new System.Windows.Forms.ToolBarButton();
            this.ClearButton = new System.Windows.Forms.ToolBarButton();
            this.AboutButton = new System.Windows.Forms.ToolBarButton();
            this.ToobarImages = new System.Windows.Forms.ImageList(this.components);
            this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
            this.FileMenu = new System.Windows.Forms.MenuItem();
            this.MonitorMenuItem = new System.Windows.Forms.MenuItem();
            this.StopMenuItem = new System.Windows.Forms.MenuItem();
            this.ClearMenuItem = new System.Windows.Forms.MenuItem();
            this.Splitter1MenuItem = new System.Windows.Forms.MenuItem();
            this.ExitMenuItem = new System.Windows.Forms.MenuItem();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.HelpMenu = new System.Windows.Forms.MenuItem();
            this.AboutMenuItem = new System.Windows.Forms.MenuItem();
            this.StatusBar = new System.Windows.Forms.StatusBar();
            this.PacketList = new System.Windows.Forms.ListView();
            this.TimeHeader = new System.Windows.Forms.ColumnHeader();
            this.ProtocolHeader = new System.Windows.Forms.ColumnHeader();
            this.SourceHeader = new System.Windows.Forms.ColumnHeader();
            this.DestinationHeader = new System.Windows.Forms.ColumnHeader();
            this.LengthHeader = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // ToolBar
            // 
            this.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.ToolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.StartButton,
            this.StopButton,
            this.ClearButton,
            this.AboutButton});
            this.ToolBar.Cursor = System.Windows.Forms.Cursors.Default;
            this.ToolBar.DropDownArrows = true;
            this.ToolBar.ImageList = this.ToobarImages;
            this.ToolBar.Location = new System.Drawing.Point(0, 0);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.ShowToolTips = true;
            this.ToolBar.Size = new System.Drawing.Size(861, 28);
            this.ToolBar.TabIndex = 1;
            this.ToolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.OnToolBarClick);
            // 
            // StartButton
            // 
            this.StartButton.DropDownMenu = this.HostsMenu;
            this.StartButton.ImageIndex = 0;
            this.StartButton.Name = "StartButton";
            this.StartButton.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
            this.StartButton.ToolTipText = "Start monitoring";
            // 
            // StopButton
            // 
            this.StopButton.ImageIndex = 1;
            this.StopButton.Name = "StopButton";
            this.StopButton.ToolTipText = "Stop monitoring";
            // 
            // ClearButton
            // 
            this.ClearButton.ImageIndex = 3;
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.ToolTipText = "Clear packet list";
            // 
            // AboutButton
            // 
            this.AboutButton.ImageIndex = 2;
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.ToolTipText = "About...";
            // 
            // ToobarImages
            // 
            this.ToobarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ToobarImages.ImageStream")));
            this.ToobarImages.TransparentColor = System.Drawing.Color.Magenta;
            this.ToobarImages.Images.SetKeyName(0, "");
            this.ToobarImages.Images.SetKeyName(1, "");
            this.ToobarImages.Images.SetKeyName(2, "");
            this.ToobarImages.Images.SetKeyName(3, "");
            // 
            // MainMenu
            // 
            this.MainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.FileMenu,
            this.menuItem1,
            this.menuItem7,
            this.menuItem9,
            this.HelpMenu});
            // 
            // FileMenu
            // 
            this.FileMenu.Index = 0;
            this.FileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.MonitorMenuItem,
            this.StopMenuItem,
            this.ClearMenuItem,
            this.Splitter1MenuItem,
            this.ExitMenuItem});
            this.FileMenu.Text = "&File";
            // 
            // MonitorMenuItem
            // 
            this.MonitorMenuItem.Index = 0;
            this.MonitorMenuItem.Text = "Monitor";
            this.MonitorMenuItem.Click += new System.EventHandler(this.MonitorMenuItem_Click);
            // 
            // StopMenuItem
            // 
            this.StopMenuItem.Index = 1;
            this.StopMenuItem.Text = "&Stop monitoring";
            this.StopMenuItem.Click += new System.EventHandler(this.StopMenuItem_Click);
            // 
            // ClearMenuItem
            // 
            this.ClearMenuItem.Index = 2;
            this.ClearMenuItem.Text = "&Clear packet list";
            this.ClearMenuItem.Click += new System.EventHandler(this.ClearMenuItem_Click);
            // 
            // Splitter1MenuItem
            // 
            this.Splitter1MenuItem.Index = 3;
            this.Splitter1MenuItem.Text = "-";
            // 
            // ExitMenuItem
            // 
            this.ExitMenuItem.Index = 4;
            this.ExitMenuItem.Text = "E&xit";
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 1;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem4,
            this.menuItem2,
            this.menuItem3});
            this.menuItem1.Text = "Flood Attack";
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 0;
            this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem5,
            this.menuItem6});
            this.menuItem4.Text = "Monitoring";
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 0;
            this.menuItem5.Text = "Start";
            this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 1;
            this.menuItem6.Text = "Stop";
            this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 1;
            this.menuItem2.Text = "Define Q length";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 2;
            this.menuItem3.Text = "Marked Packets List";
            this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 2;
            this.menuItem7.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem8});
            this.menuItem7.Text = "MITM";
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 0;
            this.menuItem8.Text = "Ip list";
            this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 3;
            this.menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem10,
            this.menuItem11});
            this.menuItem9.Text = "Alert";
            this.menuItem9.Visible = false;
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 0;
            this.menuItem10.Text = "Send Sms ";
            this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
            // 
            // menuItem11
            // 
            this.menuItem11.Index = 1;
            this.menuItem11.Text = "Mobile List";
            this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
            // 
            // HelpMenu
            // 
            this.HelpMenu.Index = 4;
            this.HelpMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.AboutMenuItem});
            this.HelpMenu.Text = "&Help";
            // 
            // AboutMenuItem
            // 
            this.AboutMenuItem.Index = 0;
            this.AboutMenuItem.Text = "&About";
            this.AboutMenuItem.Click += new System.EventHandler(this.AboutMenuItem_Click);
            // 
            // StatusBar
            // 
            this.StatusBar.Location = new System.Drawing.Point(0, 475);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(861, 16);
            this.StatusBar.TabIndex = 3;
            this.StatusBar.PanelClick += new System.Windows.Forms.StatusBarPanelClickEventHandler(this.StatusBar_PanelClick);
            // 
            // PacketList
            // 
            this.PacketList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TimeHeader,
            this.ProtocolHeader,
            this.SourceHeader,
            this.DestinationHeader,
            this.LengthHeader});
            this.PacketList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PacketList.FullRowSelect = true;
            this.PacketList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.PacketList.Location = new System.Drawing.Point(0, 28);
            this.PacketList.MultiSelect = false;
            this.PacketList.Name = "PacketList";
            this.PacketList.Size = new System.Drawing.Size(861, 447);
            this.PacketList.TabIndex = 4;
            this.PacketList.UseCompatibleStateImageBehavior = false;
            this.PacketList.View = System.Windows.Forms.View.Details;
            this.PacketList.SelectedIndexChanged += new System.EventHandler(this.PacketList_SelectedIndexChanged);
            this.PacketList.DoubleClick += new System.EventHandler(this.OnPacketDoubleClick);
            // 
            // TimeHeader
            // 
            this.TimeHeader.Text = "Time";
            this.TimeHeader.Width = 120;
            // 
            // ProtocolHeader
            // 
            this.ProtocolHeader.Text = "Protocol";
            // 
            // SourceHeader
            // 
            this.SourceHeader.Text = "Source";
            this.SourceHeader.Width = 130;
            // 
            // DestinationHeader
            // 
            this.DestinationHeader.Text = "Destination";
            this.DestinationHeader.Width = 130;
            // 
            // LengthHeader
            // 
            this.LengthHeader.Text = "Length";
            // 
            // PacketMonitormForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(861, 491);
            this.Controls.Add(this.PacketList);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.ToolBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Menu = this.MainMenu;
            this.Name = "PacketMonitormForm";
            this.Text = "Flood Attack & MITM for network Instrusion detection.";
            this.Load += new System.EventHandler(this.PacketMonitormForm_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.PacketMonitormForm_Closing);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PacketMonitormForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

       
		static void Main() {
            try
            {
                Application.Run(new MainScreen());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Red.org Packet Monitor", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
		}
		private void Initialize() {
			// get all interfaces on this computer and list them
			IPAddress[] hosts = Dns.Resolve(Dns.GetHostName()).AddressList;
			if (hosts.Length == 0)
				throw new NotSupportedException("This computer does not have non-loopback interfaces installed!");
			for(int i = 0; i < hosts.Length; i++) {
				MonitorMenuItem.MenuItems.Add(hosts[i].ToString(), new EventHandler(this.OnHostsClick));
				HostsMenu.MenuItems.Add(hosts[i].ToString(), new EventHandler(this.OnHostsClick));
			}
			m_PacketMonitors = new PacketMonitor[HostsMenu.MenuItems.Count];
			for(int i = 0; i < m_PacketMonitors.Length; i++) {
				m_PacketMonitors[i] = new PacketMonitor(hosts[i]);
				m_PacketMonitors[i].NewPacket += new NewPacketEventHandler(this.OnNewPacket);
			}
			m_Packets = new ArrayList();
		}
		private void PacketMonitormForm_Closing(object sender, CancelEventArgs e) {
			OnToolBarClick(this, new ToolBarButtonClickEventArgs(StopButton));
		}
		public void OnToolBarClick(object sender, ToolBarButtonClickEventArgs e) {
			if (e.Button == StopButton) { // stop listening on all interfaces
				for(int i = 0; i < m_PacketMonitors.Length; i++) {
					m_PacketMonitors[i].Stop();
					HostsMenu.MenuItems[i].Checked = false;
					MonitorMenuItem.MenuItems[i].Checked = false;
				}
				StatusBar.Text = "Stopped monitoring";
			} else if (e.Button == StartButton) { // start listening on all interfaces
				for(int i = 0; i < m_PacketMonitors.Length; i++) {
					try {
						m_PacketMonitors[i].Start();
					} catch (Exception ex) {
						MessageBox.Show(this, "There was a problem starting the packet monitor for interface " + m_PacketMonitors[i].IP.ToString() + "\r\n\r\n[" + ex.Message + "]", "Red.org Packet Monitor", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					HostsMenu.MenuItems[i].Checked = true;
					MonitorMenuItem.MenuItems[i].Checked = true;
				}
				StatusBar.Text = "Monitoring all interfaces";
		} else if (e.Button == ClearButton) { // clear the packet list
				PacketList.Items.Clear();
				m_Packets.Clear();
				StatusBar.Text = "Cleared packet list";
			} else if (e.Button == AboutButton) {
				AboutForm af = new AboutForm();
				af.ShowDialog(this);
			}
		}
		public void OnHostsClick(object sender, EventArgs e) {
			// start or stop listening on the specified interface
			int index = ((MenuItem)sender).Index;
			HostsMenu.MenuItems[index].Checked = !HostsMenu.MenuItems[index].Checked;
			MonitorMenuItem.MenuItems[index].Checked = HostsMenu.MenuItems[index].Checked;
			if (HostsMenu.MenuItems[index].Checked) {
				m_PacketMonitors[index].Start();
				StatusBar.Text = "Monitoring " + m_PacketMonitors[index].IP.ToString();
			} else {
				m_PacketMonitors[index].Stop();
				StatusBar.Text = "Stopped monitoring " + m_PacketMonitors[index].IP.ToString();
			}
		}
		public void OnPacketDoubleClick(object sender, EventArgs e) {
			ListView l = (ListView)sender;
			if (l.SelectedItems.Count > 0) {
				PacketForm pf = new PacketForm(  (Packet)m_Packets[   l.SelectedItems[0].Index  ]   );
				pf.Show();
			}
		}
		private void OnNewPacket(PacketMonitor pm, Packet p) {
			// add the new packet to the list
            GlobalPacket = p;
            Global.PacketForGraph = p;
			m_Packets.Add(p);
			m_PacketsSize += p.TotalLength;

            this.Invoke(new UpdatePacketList(OnUpdatePacketList), p);
			//PacketList.Items.Add(new ListViewItem(new string[] { p.Time.ToString(), p.Protocol.ToString(), p.Source, p.Destination, p.TotalLength.ToString() }));
			//StatusBar.Text = string.Format("Intercepted {0} packet(s) [{1} bytes]", m_Packets.Count, m_PacketsSize);
            //UpdatePacketList
		}

        private void OnUpdatePacketList(Packet p) {
            string[] IpPortSrc = p.Source.Split(':');
            string[] IpPortDst = p.Destination.Split(':');
            ListViewItem L = new ListViewItem(p.Time.ToString());
            L.SubItems.Add(p.Protocol.ToString());
            L.SubItems.Add(p.Source );
            L.SubItems.Add(p.Destination);
            L.SubItems.Add(p.TotalLength.ToString());
            if (Global.IpList.Contains(IpPortSrc[0]) == false )
            {
                SoundPlayer spWave;
                spWave = new SoundPlayer(System.IO.Directory.GetCurrentDirectory() + "/alarm.wav");
                L.BackColor = System.Drawing.Color.Red;
                spWave.Play();
                if (Global.IntruderList.Contains(IpPortSrc[0]))
                    Global.IntruderList.Add(IpPortSrc[0]);
            }
            else if (Global.IntruderList.Contains(IpPortDst[0]) == true)
            {
                SoundPlayer spWave;
                spWave = new SoundPlayer(System.IO.Directory.GetCurrentDirectory() + "/alarm.wav");
                L.BackColor = System.Drawing.Color.Red;
                spWave.Play();
            }
            PacketList.Items.Add(L);
            //PacketList.Items.Add(new ListViewItem(new string[] { p.Time.ToString(), p.Protocol.ToString(), p.Source, p.Destination, p.TotalLength.ToString() }));
            StatusBar.Text = string.Format("Intercepted {0} packet(s) [{1} bytes]", m_Packets.Count, m_PacketsSize);
        }

		private void StopMenuItem_Click(object sender, System.EventArgs e) {
			OnToolBarClick(this, new ToolBarButtonClickEventArgs(StopButton));
		}
		private void ClearMenuItem_Click(object sender, System.EventArgs e) {
			OnToolBarClick(this, new ToolBarButtonClickEventArgs(ClearButton));
		}
		private void AboutMenuItem_Click(object sender, System.EventArgs e) {
			OnToolBarClick(this, new ToolBarButtonClickEventArgs(AboutButton));
		}
        private void ExitMenuItem_Click(object sender, System.EventArgs e)
        {
            GetIpThreads.Abort();
            SaveIntruderList();
            for (int i = 0; i < Application.OpenForms.Count; i++)
                Application.OpenForms[i].Close();

            Application.Exit();
        }
		private System.Windows.Forms.ListView PacketList;
		private System.Windows.Forms.MainMenu MainMenu;
		private System.Windows.Forms.ImageList ToobarImages;
		private System.Windows.Forms.ToolBar ToolBar;
		private System.Windows.Forms.StatusBar StatusBar;
		private System.Windows.Forms.ToolBarButton StartButton;
		private System.Windows.Forms.ToolBarButton StopButton;
		private System.Windows.Forms.ToolBarButton AboutButton;
		private System.Windows.Forms.ToolBarButton ClearButton;
		private System.Windows.Forms.MenuItem FileMenu;
		private System.Windows.Forms.MenuItem ExitMenuItem;
		private System.Windows.Forms.MenuItem HelpMenu;
		private System.Windows.Forms.MenuItem AboutMenuItem;
		private System.Windows.Forms.ColumnHeader TimeHeader;
		private System.Windows.Forms.ColumnHeader ProtocolHeader;
		private System.Windows.Forms.ColumnHeader SourceHeader;
		private System.Windows.Forms.ColumnHeader DestinationHeader;
		private System.Windows.Forms.ColumnHeader LengthHeader;
		private System.Windows.Forms.MenuItem MonitorMenuItem;
		private System.Windows.Forms.MenuItem StopMenuItem;
		private System.Windows.Forms.MenuItem ClearMenuItem;
		private System.Windows.Forms.MenuItem Splitter1MenuItem;
		private System.Windows.Forms.ContextMenu HostsMenu;
		private System.ComponentModel.IContainer components;
		private PacketMonitor[] m_PacketMonitors;
        private Packet GlobalPacket;           
		private ArrayList m_Packets;
        private MenuItem menuItem1;
        private MenuItem menuItem2;
        private MenuItem menuItem3;
        private MenuItem menuItem4;
        private MenuItem menuItem5;
        private MenuItem menuItem6;
		private int m_PacketsSize = 0;
        private Thread delay = null;
        private MenuItem menuItem7;
        private MenuItem menuItem8;
        private MenuItem menuItem9;
        private MenuItem menuItem10;
        private MenuItem menuItem11;
        private Thread redThread = null;

        private void PacketList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menuItem2_Click(object sender, EventArgs e)
        {
          new QLen().Show();
        }


        private void menuItem5_Click(object sender, EventArgs e)
        {
            redThread = new Thread(new ThreadStart(redAlgorithm));
            redThread.Start();
            delay = new Thread(new ThreadStart(delayFunc));
            delay.Start();
        }

        private void delayFunc()
        {
            Thread.Sleep(Global.QSecs * 1000);
            redThread.Abort();
            delay.Abort();
        }

        public void redAlgorithm()
        {
            while (true)
            {
                try
                {
                    if (GlobalPacket.Source == null) continue;
                    if (Global.hashtable.ContainsKey(GlobalPacket.Source))
                    {
                        string val = Convert.ToString(int.Parse(Global.hashtable[GlobalPacket.Source].ToString()) + 1);
                        //MessageBox.Show(val);
                        Global.hashtable.Remove(GlobalPacket.Source);
                        Global.hashtable.Add(GlobalPacket.Source, val);
                    }
                    else
                        Global.hashtable.Add(GlobalPacket.Source, "1");
                }
                catch (Exception e) { }
            }
        }

        private void menuItem3_Click(object sender, EventArgs e)
        {
            (new RedPackets()).Show();
        }

        private void MonitorMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuItem6_Click(object sender, EventArgs e)
        {
            if (redThread.IsAlive && delay.IsAlive)
            {
                MessageBox.Show("Stop Red algorithm calibration thread , Before goto red alert list", "Red algorithm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            redThread.Abort();
            delay.Abort();
        }

        private void menuItem8_Click(object sender, EventArgs e)
        {
            new IntruderList().Show();
        }

        private void StatusBar_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {

        }

        UdpReceiver recv;
        Thread GetIpThreads;
        private void PacketMonitormForm_Load(object sender, EventArgs e)
        {
            recv = new UdpReceiver(9999);
            IPAddress[] hosts = Dns.Resolve(Dns.GetHostName()).AddressList;
            Global.IpList.Add(hosts[0].ToString());
            GetIpThreads = new Thread(new ThreadStart(GetIpListTimer));
            GetIpThreads.Start();

            string[] ipList = IntruderClass.GetIntruderList().Split(',');
            for (int i = 0; i < ipList.Length; i++)
                Global.IntruderList.Add(ipList[i]);
        }

        private void PacketMonitormForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveIntruderList();
        }

        private void SaveIntruderList()
        {
            System.IO.FileStream fp = new System.IO.FileStream("c:/intruder.txt", System.IO.FileMode.Create);
            System.IO.StreamWriter writer = new System.IO.StreamWriter(fp);
            for (int i = 0; i < Global.IntruderList.Count; i++)
            {
                string ip = Global.IntruderList[i].ToString().TrimStart().TrimEnd();
                if (i < Global.IntruderList.Count - 1)
                    writer.WriteLine(ip + ",");
                else
                    writer.WriteLine(ip);
            }
            writer.Close();
            fp.Close();
        }

        private void menuItem9_Click(object sender, EventArgs e)
        {
            SoundPlayer spWave;
            spWave = new SoundPlayer(System.IO.Directory.GetCurrentDirectory() + "/alarm.wav");
            spWave.Play();
        }


        void GetIpListTimer()
        {
            while (GetIpThreads.IsAlive)
            {
                string data = recv.Receive();
                if (data.StartsWith("Part of the network")) // just a data from the broadcaster
                {
                    string ip = data.Split(':')[1];
                    if (Global.IpList.Contains(ip) == false)
                        Global.IpList.Add(ip);
                }
                System.Threading.Thread.Sleep(1000);
            }
        }

        private void menuItem10_Click(object sender, EventArgs e)
        {
            if (PacketList.SelectedIndices.Count > 0)
            {
                string []ip = PacketList.SelectedItems[0].SubItems[2].Text.Split(':');  //destination 192.156.1.12:80
                Global.IntruderList.Add(ip[0]);

                string path = Application.StartupPath + "/mobile.txt";
                if (System.IO.File.Exists(path))
                {
                    FileStream fp = new FileStream(path, FileMode.Open);
                    StreamReader reader = new StreamReader(fp);
                    string MNos = reader.ReadToEnd();
                    string[] No = MNos.Split(',');
                    for (int i = 0; i < No.Length; i++)
                    {
                        string MsgBody = string.Format("New intruder identified for Flood attack , Ip  = {0} please consider the further actions.", ip[0]);
                        SendSms.Send(No[i].Trim(), MsgBody, Global.port);
                    }
                }
            }
        }

        private void menuItem11_Click(object sender, EventArgs e)
        {
            Mobile m = new Mobile();
            m.Show();
        }
    }
}