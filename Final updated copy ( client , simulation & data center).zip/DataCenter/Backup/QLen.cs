﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Org.Red.Network.PacketMonitor
{
    public partial class QLen : Form
    {
        public QLen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Global.QLen = int.Parse(maskedTextBox1.Text);
            Global.QSecs = int.Parse(maskedTextBox2.Text);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void QLen_Load(object sender, EventArgs e)
        {
            maskedTextBox1.Text = Global.QLen.ToString();
            maskedTextBox2.Text = Global.QSecs.ToString();
        }
    }
}
