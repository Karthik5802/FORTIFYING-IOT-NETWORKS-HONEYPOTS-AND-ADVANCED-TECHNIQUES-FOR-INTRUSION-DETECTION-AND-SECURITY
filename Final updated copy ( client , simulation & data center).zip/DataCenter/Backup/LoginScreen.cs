﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Org.Red.Network.PacketMonitor
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void LoginScreen_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("admin") && textBox2.Text.Equals("password"))
            {
                this.Hide();
                (new PacketMonitormForm()).Show();
            }
            else
                MessageBox.Show("Invalid username/password", "Authentication failed", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
