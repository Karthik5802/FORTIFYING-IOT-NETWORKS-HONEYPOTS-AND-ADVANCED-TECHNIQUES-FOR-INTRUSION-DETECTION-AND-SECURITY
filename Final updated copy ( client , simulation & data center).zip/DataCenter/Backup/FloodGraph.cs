﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Org.Red.Network.PacketMonitor 
{
    public partial class FloodGraph : Form
    {
        public FloodGraph()
        {
            InitializeComponent();
        }
         Random r = new Random();
        private void button1_Click(object sender, EventArgs e)
         {
           
        }

        Thread thread;
        Thread redThread;
        private void button2_Click(object sender, EventArgs e)
        {
            perfcharts.PerfChartStyle.ChartLinePen.Color = System.Drawing.Color.Yellow;
            perfcharts.BorderStyle = Border3DStyle.Bump;
            perfcharts.ScaleMode = SpPerfChart.ScaleMode.Relative;
            if (button2.Text == "Start")
            {
                if (txtQLen.Text.Length != 0)
                    Global.QLen = int.Parse(txtQLen.Text);        //Custom 

                redThread = new Thread(new ThreadStart(redAlgorithm));
                redThread.Start();

                thread = new Thread(new ThreadStart(monitor));
                thread.Start();
                button2.Text = "Stop";
                lblSTime.Text = DateTime.Now.ToLongTimeString();
            }
            else
            {
                perfchart.Clear();
                if (thread.IsAlive) thread.Abort();
                if (redThread.IsAlive) redThread.Abort();
                button2.Text = "Start";
            }
        }


        public void redAlgorithm()
        {
            while ( redThread.IsAlive )
            {
                try
                {
                    if (Global.PacketForGraph.Source == null) continue;
                    if (Global.hashtable.ContainsKey(Global.PacketForGraph.Source))
                    {
                        string val = Convert.ToString(int.Parse(Global.hashtable[Global.PacketForGraph.Source].ToString()) + 1);
                        Global.hashtable.Remove(Global.PacketForGraph.Source);
                        Global.hashtable.Add(Global.PacketForGraph.Source, val);
                    }
                    else
                        Global.hashtable.Add(Global.PacketForGraph.Source , "1");
                }
                catch (Exception e) { }
            }
        }

        private void monitor()
        {
            while (thread.IsAlive)
            {
                lblRTime.Text = DateTime.Now.ToLongTimeString();
                lblDestination.Text       = "Destination               :" + Global.PacketForGraph.Destination;
                lblPacketSize.Text       = "Packet Size              :" + Global.PacketForGraph.TotalLength;
                lblProtocol.Text            = "Protocol type           :" + Global.PacketForGraph.Protocol;
                lblTime.Text                  = "Time                          :" + Global.PacketForGraph.Time.ToString();
                lblTTL.Text                    = "Time to Live             :" + Global.PacketForGraph.TimeToLive;
                lblPacketVersion.Text = "Packet version        :" + Global.PacketForGraph.Version;
                lblSource.Text               = "Source ip                 :" + Global.PacketForGraph.Source;

                if (Global.PacketForGraph != null)
                {
                    int genValue = Global.PacketForGraph.TotalLength % 100;   //r.Next(1 , 100);
                    perfcharts.AddValue(genValue);
                }
                Thread.Sleep(1000);
            }
        }

        private void FloodGraph_Load(object sender, EventArgs e)
        {
            Label.CheckForIllegalCrossThreadCalls = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //perfcharts.BorderStyle = Border3DStyle.Sunken;
            //perfcharts.ScaleMode = SpPerfChart.ScaleMode.Relative;
            //decimal v = Convert.ToDecimal(r.NextDouble() * 100);
            //perfcharts.PerfChartStyle.ChartLinePen.Color = System.Drawing.Color.Yellow;
            //perfcharts.AddValue(v);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Global.QLen = 250;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Global.QLen = 730;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Global.QLen = 3000;
        }
    }
}
