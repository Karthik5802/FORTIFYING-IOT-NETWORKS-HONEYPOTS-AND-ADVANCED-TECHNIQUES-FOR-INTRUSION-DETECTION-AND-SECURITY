﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
namespace Org.Red.Network.PacketMonitor
{
    class Global
    {
        public static int QLen = 0;
        public static Hashtable hashtable = new Hashtable();
        public static int QSecs = 10;
        public static ArrayList IntruderList = new ArrayList();
        public static string port = "59";
        public static ArrayList IpList = new ArrayList();
        public static  Packet PacketForGraph;  
    }
}
