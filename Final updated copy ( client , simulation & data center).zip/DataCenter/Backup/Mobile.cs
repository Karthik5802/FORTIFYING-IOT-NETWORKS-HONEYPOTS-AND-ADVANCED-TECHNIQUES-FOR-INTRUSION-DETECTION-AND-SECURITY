﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Org.Red.Network.PacketMonitor 
{
    public partial class Mobile : Form
    {
        public Mobile()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Contains(textBox1.Text) == false )
            {
                listBox1.Items.Add(textBox1.Text);
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1 )      // some No. is selected
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }

        private void Mobile_Load(object sender, EventArgs e)
        {
            txtPort.Text =
            string path = Application.StartupPath + "/mobile.txt";
            if (System.IO.File.Exists(path))
            {
                FileStream fp = new FileStream(path, FileMode.Open);
                StreamReader reader = new StreamReader(fp);
                string MNos = reader.ReadToEnd();
                string [ ] No = MNos.Split(',');
                for (int i = 0; i < No.Length; i++)
                {
                    listBox1.Items.Add(No[i].Trim());
                }

                reader.Close();
                fp.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = Application.StartupPath + "/mobile.txt";

            string M = "";
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                listBox1.SelectedIndex = i;
                M = M + listBox1.GetItemText(listBox1.SelectedItem) + ",";
            }
            M = M.Substring(0, M.Length - 1);

            FileStream fp = new FileStream(path, FileMode.Create);
            StreamWriter writer = new StreamWriter(fp);
            writer.WriteLine(M);
            writer.Close();
            fp.Close();
        }
    }
}
