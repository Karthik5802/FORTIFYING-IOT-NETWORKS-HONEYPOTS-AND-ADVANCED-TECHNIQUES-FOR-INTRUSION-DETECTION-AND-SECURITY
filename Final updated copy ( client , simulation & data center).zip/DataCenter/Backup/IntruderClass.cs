﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace Org.Red.Network.PacketMonitor
{
    class IntruderClass
    {
        public static string GetIntruderList()
        {
            string content = "null";
            if (File.Exists("c:/intruder.txt"))
            {
                FileStream fp = new FileStream("c:/intruder.txt", FileMode.Open);
                StreamReader reader = new StreamReader(fp);
                 content = "";
                 string data;
                 while ( (data = reader.ReadLine()) != null)
                 {
                     content = content + data;
                 }
                reader.Close();
                fp.Close();
            }
            return content;
        }
    }
}
