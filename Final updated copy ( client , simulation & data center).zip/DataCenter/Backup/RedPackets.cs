﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
namespace Org.Red.Network.PacketMonitor
{
    public partial class RedPackets : Form
    {
        public RedPackets()
        {
            InitializeComponent();
        }
        private int sortColumn = -1;

        private void RedPackets_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("Ip-Address", 200, HorizontalAlignment.Left);
            listView1.Columns.Add("Packets count", 250, HorizontalAlignment.Left);
            listView1.Columns.Add("Threat zone", 250, HorizontalAlignment.Left);
            if (Global.hashtable.Count != 0)
            {
                foreach (DictionaryEntry Item in Global.hashtable)
                {
                    if (int.Parse(Item.Value.ToString()) >= Global.QLen)
                    {
                        ListViewItem newListItem = new ListViewItem(Item.Key.ToString());
                        newListItem.Name = Item.Key.ToString();
                        newListItem.SubItems.Add(Item.Value.ToString());

                        if (Global.IpList.Contains(Item.Key.ToString().Split(':')[0]))
                            newListItem.SubItems.Add("Internal threat");
                        else
                            newListItem.SubItems.Add("External threat");

                        if (listView1.Items.ContainsKey(newListItem.Name) == false)
                        {
                            listView1.Items.Add(newListItem);
                        }
                    }
                }
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addToIntruderListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                string[] ipPort = listView1.SelectedItems[0].Text.Split(':');  //192.156.1.12:80
                Global.IntruderList.Add(ipPort[0]);

                //string path = Application.StartupPath + "/mobile.txt";
                //if (System.IO.File.Exists(path))
                //{
                //    FileStream fp = new FileStream(path, FileMode.Open);
                //    StreamReader reader = new StreamReader(fp);
                //    string MNos = reader.ReadToEnd();
                //    string[] No = MNos.Split(',');
                //    for (int i = 0; i < No.Length; i++)
                //    {
                //        string MsgBody = string.Format("New intruder identified for Flood attack , Ip  = {0} please consider the further actions.",  ipPort[0]);
                //        SendSms.Send(No[i].Trim(), MsgBody, Global.port);
                //    }
                //}
            }
        }

        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column != sortColumn)
            {
                // Set the sort column to the new column.
                sortColumn = e.Column;
                // Set the sort order to ascending by default.
                listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                // Determine what the last sort order was and change it.
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }

            // Call the sort method to manually sort.
            listView1.Sort();
            // Set the ListViewItemSorter property to a new ListViewItemComparer
            // object.
            this.listView1.ListViewItemSorter = new ListViewItemComparer(e.Column, listView1.Sorting);
        }


        class ListViewItemComparer : IComparer
        {
            private int col;
            private SortOrder order;
            public ListViewItemComparer()
            {
                col = 0;
                order = SortOrder.Ascending;
            }
            public ListViewItemComparer(int column, SortOrder order)
            {
                col = column;
                this.order = order;
            }

            public int Compare(object x, object y)
            {
                int returnVal = -1;
                if (col == 0)
                {
                    returnVal = String.Compare(((ListViewItem)x).SubItems[col].Text,
                                            ((ListViewItem)y).SubItems[col].Text);
                }
                else if (col == 1)
                {
                    returnVal = int.Parse(((ListViewItem)x).SubItems[col].Text) > int.Parse(((ListViewItem)y).SubItems[col].Text) ? 1 : -1;
                }
                // Determine whether the sort order is descending.
                if (order == SortOrder.Descending)
                    // Invert the value returned by String.Compare.
                    returnVal *= -1;
                return returnVal;
            }
        }
    }
}

