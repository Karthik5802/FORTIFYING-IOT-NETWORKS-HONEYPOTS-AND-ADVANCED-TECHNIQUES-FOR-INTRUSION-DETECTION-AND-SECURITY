﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.ComponentModel;
using System.Threading;
using System.IO;
namespace Org.Red.Network.PacketMonitor
{
    class SendSms
    {
            static AutoResetEvent readNow = new AutoResetEvent(false);
            static SerialPort port;

            private static string ExecuteCommand(string command, int timeout)
            {
                byte[] replyData = new byte[80];
                port.DiscardInBuffer();
                port.DiscardOutBuffer();
                readNow.Reset();
                port.Write(command + "\r");
                port.Read(replyData, 0, replyData.Length);
                return ASCIIEncoding.ASCII.GetString(replyData);
            }

            private static SerialPort EstablishConnection(string portName)
            {
                SerialPort port = new SerialPort();
                if (portName.ToUpper().StartsWith("COM") == false) portName = "COM" + portName;
                port.PortName = portName;
                port.BaudRate = 9600;
                port.DataBits = 8;
                port.StopBits = StopBits.One;
                port.Parity = Parity.None;
                //port.ReadTimeout = 2000;
                //port.WriteTimeout = 5000;
                port.Encoding = Encoding.GetEncoding("iso-8859-1");
                port.DataReceived += new SerialDataReceivedEventHandler(DataReceived);
                port.Open();
                port.DtrEnable = true;  // data terminal ready
                port.RtsEnable = true;   // request to send
                return port;
            }

            private static void DataReceived(object sender, SerialDataReceivedEventArgs e)
            {
                if (e.EventType == SerialData.Chars)
                    readNow.Set();
            }

            public static bool Send(string Mobile, string Message, string portname)
            {
                try
                {
                    port = EstablishConnection(portname);
                }
                catch
                {
                    return false;
                }
                string recievedData = ExecuteCommand("AT", 300);
                recievedData = ExecuteCommand("AT+CMGF=1", 300);
                String command = "AT+CMGS=\"" + Mobile + "\"";
                recievedData = ExecuteCommand(command, 300);
                string message = Message;
                command = message + char.ConvertFromUtf32(26) + "\r";
                recievedData = ExecuteCommand(command, 300);
                if (recievedData.EndsWith("\r\nOK\r\n")) recievedData = "Message sent successfully";
                if (recievedData.Contains("ERROR"))
                {
                    port.Close();
                    return false;
                }
                else
                {
                    port.Close();
                    return true;
                }
            }
        }
    }

