﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Org.Red.Network.PacketMonitor
{
    public partial class IntruderList : Form
    {
        public IntruderList()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void IntruderList_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Global.IntruderList.Count; i++)
            {
                if (Global.IntruderList[i].ToString().Trim().Length == 0 || Global.IntruderList[i].ToString().Trim().ToLower().Equals("null")) continue;
                listBox1.Items.Add(Global.IntruderList[i].ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ( ! Global.IntruderList.Contains(textBox1.Text))
            {
                Global.IntruderList.Add(textBox1.Text);
                listBox1.Items.Add(textBox1.Text);
            }
            else
                MessageBox.Show("Ip entry already exists", "Intruder list", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void deleteIPFromBlackListToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int p = listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(p);
            Global.IntruderList.RemoveAt(p);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
