﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Org.Red.Network.PacketMonitor 
{
    public partial class AttackReport : Form
    {
         
        public AttackReport( )
        {
            InitializeComponent();
          
        }

        private void AttackReport_Load(object sender, EventArgs e)
        {
            string intruderlistData = Packet.getPackets().Replace('\r', '\n');
            string[] informations = intruderlistData.Split('\n');
            for( int i=0; i<informations.Length; i++)
            {
                if (informations[i].Trim().Length == 0) continue;
                string[] cols = informations[i].Trim().Split(',');
                if (cols.Length != 3) continue;
                ListViewItem item = new ListViewItem(cols[0]);
                item.SubItems.Add(cols[1]);
                item.SubItems.Add(cols[2]);
                AttackList.Items.Add(item);
            }
        }
    }
}
