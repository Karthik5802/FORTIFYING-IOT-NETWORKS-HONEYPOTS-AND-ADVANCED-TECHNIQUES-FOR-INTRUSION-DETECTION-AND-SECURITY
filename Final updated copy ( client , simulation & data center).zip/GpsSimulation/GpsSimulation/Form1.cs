﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace GpsSimulation
{
    public partial class Form1 : Form
    {
        MqttClient client = null, pubclient = null;
        string clientId;
        string mqttserverip = "broker.hivemq.com";
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            if (client != null)
                client.Disconnect();
            Application.ExitThread();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client = new MqttClient(mqttserverip);
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TxtLon.Text.Length == 0 || TxtLat.Text.Length == 0)
                MessageBox.Show("Input gps data before publish", "Gps", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                string data = TxtLat.Text + "," + TxtLon.Text;
                client.Publish("cybersecurepot/gps", Encoding.UTF8.GetBytes(data), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
                MessageBox.Show("Data published successfully", "Gps", MessageBoxButtons.OK , MessageBoxIcon.Information);
            }

        }
    }
}
