﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;
using System.Net.Sockets;

namespace RequestPackets
{
    [Serializable]
    public class RequestPacket
    {
        public string Ip { set; get; }
        public string Username { set; get; }
        public string MachineName { set; get; }
        public string DateTime { set; get; }
        public string Reqtype { set; get; }
        public string Response { set; get; }
    }


    public class DataHandler
    {
        public static byte[] Serialize<T>(T obj)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, obj);
                return ms.ToArray();
            }
        }

        public static T Deserialize<T>(byte[] data)
        {
            using (MemoryStream ms = new MemoryStream(data))
            {
                BinaryFormatter bf = new BinaryFormatter();
                return (T)bf.Deserialize(ms);
            }
        }

        public static string GetLocalIp()
        {
            IPAddress[] ips = Dns.GetHostEntry(Environment.MachineName).AddressList;
            foreach (IPAddress ip in ips)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    //if (ip.ToString().StartsWith("192"))
                    return ip.ToString();
                }
            }
            return "127.0.0.1"; // localhost
        }
    }
}

