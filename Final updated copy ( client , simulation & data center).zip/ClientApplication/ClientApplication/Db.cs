﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
namespace ClientApplication
{

    public class SensorResponse
    {
        public string id { set; get; }
        public string vehcount{ set;get;}
        public string rainstatus{ set;get;}
    }

    class Db
    {
        MySqlConnection con = null;
        MySqlCommand cmd = null;
        private string ip;
        public Db()
        {
            con = new MySqlConnection("server=148.72.232.170;database=dbmetric;user id=usrdbmetric;pwd=Yy2iy18^;port=3306");
            con.Open();
            cmd = new MySqlCommand();
            cmd.Connection = con;
            ip = RequestPackets.DataHandler.GetLocalIp();
        }

        public void Close()
        {
            cmd.Dispose();
            con.Close();
        }

        public SensorResponse Get( )
        {
            con = new MySqlConnection("server=148.72.232.170;database=dbmetric;user id=usrdbmetric;pwd=Yy2iy18^;port=3306");
            con.Open();
            cmd = new MySqlCommand();
            cmd.Connection = con;
            string sql = string.Format("select * from RequestHandler where id = ( select max(id) from RequestHandler where ipaddress = '{0}' and status='Y')", ip);
            SensorResponse response = new SensorResponse();
            using (MySqlDataAdapter adap = new MySqlDataAdapter(cmd))
            {
                using (DataTable buffer = new DataTable())
                {
                    adap.SelectCommand.CommandText = sql;
                    adap.Fill(buffer);

                    if (buffer.Rows.Count != 0)
                    {
                        response.id = buffer.Rows[0]["data"].ToString();
                    }
                    else
                    {
                        response.id = "";
                    }
                }
            }
            cmd.CommandText = string.Format("DELETE FROM RequestHandler WHERE ipaddress = '{0}'", ip);
            cmd.ExecuteNonQuery();
            con.Close();
            return response;
        }

    }
}
