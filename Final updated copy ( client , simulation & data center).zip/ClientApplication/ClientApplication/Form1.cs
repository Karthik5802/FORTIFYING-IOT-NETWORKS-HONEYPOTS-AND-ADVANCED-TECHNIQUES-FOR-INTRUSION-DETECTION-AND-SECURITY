﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RequestPackets;
using System.Net.Sockets;
using System.Threading;
namespace ClientApplication
{
    public partial class Form1 : Form
    {
        RequestPacket packet;
        Thread thread;
        Db obj;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnRequest_Click(object sender, EventArgs e)
        {
            
            if (TxtIp.Text.Length == 0)
            {
                MessageBox.Show("Please specify IOT server ip address", "IOT server", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            BtnRequest.Enabled = false;
            packet = new RequestPacket();
            packet.Ip = DataHandler.GetLocalIp();
            packet.MachineName = Environment.MachineName;
            packet.Username = Environment.UserName;
            packet.Reqtype = TxtPatient.Text;
            try
            {
                TcpClient client = new TcpClient(TxtIp.Text, 5000);
                NetworkStream stream = client.GetStream();
                byte[] Data = DataHandler.Serialize<RequestPacket>(packet);
                stream.Write(Data, 0, Data.Length);
                stream.Close();
                client.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Data center server not running !!", "Data center", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            System.Threading.Thread.Sleep(6000);
            BtnRequest.Enabled = true;
            BtnResponse.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListView.CheckForIllegalCrossThreadCalls = false;
            obj = new Db();
        }
 
        private void ExitPicBtn_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("You like to exit ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (res == DialogResult.Yes)
            {
                if (thread != null)
                    thread.Abort();

                obj.Close();
                Application.ExitThread();
            }
        }

        private void BtnResponse_Click(object sender, EventArgs e)
        {
            SensorResponse response = obj.Get();
            Txtresponse.Text = response.id.ToString();
            BtnResponse.Enabled = false;
        }
    }
}
