﻿namespace ClientApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnRequest = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtIp = new System.Windows.Forms.TextBox();
            this.ExitPicBtn = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtPatient = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Txtresponse = new System.Windows.Forms.TextBox();
            this.BtnResponse = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ExitPicBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnRequest
            // 
            this.BtnRequest.Location = new System.Drawing.Point(12, 165);
            this.BtnRequest.Name = "BtnRequest";
            this.BtnRequest.Size = new System.Drawing.Size(402, 53);
            this.BtnRequest.TabIndex = 0;
            this.BtnRequest.Text = "Make request";
            this.BtnRequest.UseVisualStyleBackColor = true;
            this.BtnRequest.Click += new System.EventHandler(this.BtnRequest_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Data center IP Address";
            // 
            // TxtIp
            // 
            this.TxtIp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIp.Location = new System.Drawing.Point(17, 40);
            this.TxtIp.Name = "TxtIp";
            this.TxtIp.Size = new System.Drawing.Size(258, 29);
            this.TxtIp.TabIndex = 2;
            this.TxtIp.Text = "192.168.29.227";
            // 
            // ExitPicBtn
            // 
            this.ExitPicBtn.Image = ((System.Drawing.Image)(resources.GetObject("ExitPicBtn.Image")));
            this.ExitPicBtn.Location = new System.Drawing.Point(361, 19);
            this.ExitPicBtn.Name = "ExitPicBtn";
            this.ExitPicBtn.Size = new System.Drawing.Size(53, 50);
            this.ExitPicBtn.TabIndex = 10;
            this.ExitPicBtn.TabStop = false;
            this.ExitPicBtn.Click += new System.EventHandler(this.ExitPicBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Vehicle number:";
            // 
            // TxtPatient
            // 
            this.TxtPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPatient.Location = new System.Drawing.Point(20, 108);
            this.TxtPatient.Name = "TxtPatient";
            this.TxtPatient.Size = new System.Drawing.Size(243, 23);
            this.TxtPatient.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 299);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "Data center reply";
            // 
            // Txtresponse
            // 
            this.Txtresponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtresponse.Location = new System.Drawing.Point(16, 332);
            this.Txtresponse.Name = "Txtresponse";
            this.Txtresponse.Size = new System.Drawing.Size(389, 26);
            this.Txtresponse.TabIndex = 14;
            // 
            // BtnResponse
            // 
            this.BtnResponse.Enabled = false;
            this.BtnResponse.Location = new System.Drawing.Point(15, 225);
            this.BtnResponse.Name = "BtnResponse";
            this.BtnResponse.Size = new System.Drawing.Size(398, 48);
            this.BtnResponse.TabIndex = 15;
            this.BtnResponse.Text = "View response";
            this.BtnResponse.UseVisualStyleBackColor = true;
            this.BtnResponse.Click += new System.EventHandler(this.BtnResponse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 391);
            this.Controls.Add(this.BtnResponse);
            this.Controls.Add(this.Txtresponse);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtPatient);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ExitPicBtn);
            this.Controls.Add(this.TxtIp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnRequest);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Client request application";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ExitPicBtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnRequest;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtIp;
        private System.Windows.Forms.PictureBox ExitPicBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtPatient;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Txtresponse;
        private System.Windows.Forms.Button BtnResponse;
    }
}

